import { useEffect, useState } from 'react'
import { Routes, Route, Link } from 'react-router-dom'

// --- Definice rozhraní ---
interface Majitel {
    id_majitel: number;
    jmeno: string;
    prijmeni: string;
}

interface Vozidlo {
    idVozidlo: number;
    znacka: string;
    model: string;
    rokVyroby: number;
    vin: string;
    majitel: Majitel | null;
}

// --- Komponenta pro Seznam Majitelů ---
function MajitelePage() {
    const [majitele, setMajitele] = useState<Majitel[]>([]);

    useEffect(() => {
        // Volání tvého MajitelControlleru
        fetch('http://localhost:8081/api/majitele')
            .then(res => res.json())
            .then(data => setMajitele(data))
            .catch(err => console.error(err));
    }, []);

    return (
        <div style={{ padding: '20px' }}>
            <h1>Všichni majitelé</h1>
            <Link to="/"><button>Zpět na auta</button></Link>
            <ul style={{ marginTop: '20px' }}>
                {majitele.map(m => (
                    <li key={m.id_majitel}>
                        <strong>{m.jmeno} {m.prijmeni}</strong> (ID: {m.id_majitel})
                    </li>
                ))}
            </ul>
        </div>
    );
}

// --- Hlavní komponenta App s navigací ---
function App() {
    const [vozidla, setVozidla] = useState<Vozidlo[]>([]);

    useEffect(() => {
        fetch('http://localhost:8081/api/vozidla')
            .then(response => response.json())
            .then(data => setVozidla(data))
            .catch(error => console.error('Chyba při načítání:', error));
    }, []);

    return (
        <Routes>
            {/* Cesta pro hlavní stránku */}
            <Route path="/" element={
                <div style={{ padding: '20px' }}>
                    <h1>Seznam Veteránů</h1>

                    {/* Tlačítko na další stránku */}
                    <Link to="/majitele">
                        <button style={{ marginBottom: '20px', padding: '10px', cursor: 'pointer' }}>
                            Zobrazit všechny majitele
                        </button>
                    </Link>

                    <table border={1} style={{ width: '100%', textAlign: 'left' }}>
                        <thead>
                        <tr>
                            <th>Značka</th>
                            <th>Model</th>
                            <th>Rok výroby</th>
                            <th>Majitel</th>
                        </tr>
                        </thead>
                        <tbody>
                        {vozidla.map(v => (
                            <tr key={v.idVozidlo}>
                                <td>{v.znacka}</td>
                                <td>{v.model}</td>
                                <td>{v.rokVyroby}</td>
                                <td>
                                    {v.majitel ? `${v.majitel.jmeno} ${v.majitel.prijmeni}` : 'Neznámý'}
                                </td>
                            </tr>
                        ))}
                        </tbody>
                    </table>
                </div>
            } />

            {/* Cesta pro stránku majitelů */}
            <Route path="/majitele" element={<MajitelePage />} />
        </Routes>
    )
}

export default App