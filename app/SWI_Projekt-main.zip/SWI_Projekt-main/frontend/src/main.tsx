import React from 'react'
import ReactDOM from 'react-dom/client' // Oprava importu pro ReactDOM
import './index.css'
import App from './App.tsx'
import { BrowserRouter } from 'react-router-dom' // Import pro navigaci

// Vytvoříme root jen jednou a do něj vložíme aplikaci obalenou v navigaci
ReactDOM.createRoot(document.getElementById('root')!).render(
    <React.StrictMode>
        <BrowserRouter>
            <App />
        </BrowserRouter>
    </React.StrictMode>
)