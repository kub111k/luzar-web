package cz.osu.swi_veteran;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwiVeteranApplicationTests {

    @Test
    void contextLoads() {
    }

}
