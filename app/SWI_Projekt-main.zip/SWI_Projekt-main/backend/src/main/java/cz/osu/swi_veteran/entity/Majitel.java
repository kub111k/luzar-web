package cz.osu.swi_veteran.entity;

import jakarta.persistence.*;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "majitel")
public class Majitel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_majitel;

    private String jmeno;
    private String prijmeni;
    private String email;
    private String telefon;

    // Vazba 1:N - Jeden majitel má mnoho vozidel
    @OneToMany(mappedBy = "majitel")
    @JsonIgnore // Zabrání nekonečné smyčce při výpisu do JSON
    private List<Vozidlo> vozidla;

    public Long getId_majitel() {
        return id_majitel;
    }

    public void setId_majitel(Long id_majitel) {
        this.id_majitel = id_majitel;
    }

    public String getPrijmeni() {
        return prijmeni;
    }

    public void setPrijmeni(String prijmeni) {
        this.prijmeni = prijmeni;
    }

    public String getJmeno() {
        return jmeno;
    }

    public void setJmeno(String jmeno) {
        this.jmeno = jmeno;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefon() {
        return telefon;
    }

    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }

    public List<Vozidlo> getVozidla() {
        return vozidla;
    }

    public void setVozidla(List<Vozidlo> vozidla) {
        this.vozidla = vozidla;
    }
}