package cz.osu.swi_veteran;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwiVeteranApplication {

    public static void main(String[] args) {
        SpringApplication.run(SwiVeteranApplication.class, args);
    }

}
