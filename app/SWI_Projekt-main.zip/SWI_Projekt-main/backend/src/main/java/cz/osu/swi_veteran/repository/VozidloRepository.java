package cz.osu.swi_veteran.repository;

import cz.osu.swi_veteran.entity.Vozidlo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface VozidloRepository extends JpaRepository<Vozidlo, Long> {
}