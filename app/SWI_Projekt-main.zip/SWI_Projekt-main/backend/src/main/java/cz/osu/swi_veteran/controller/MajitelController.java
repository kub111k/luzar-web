package cz.osu.swi_veteran.controller;

import cz.osu.swi_veteran.entity.Majitel;
import cz.osu.swi_veteran.repository.MajitelRepository;
import org.springframework.web.bind.annotation.*;
import java.util.List;


@RestController
@RequestMapping("/api/majitele")
@CrossOrigin(origins = "http://localhost:5173")
public class MajitelController {
    private final MajitelRepository repository;

    public MajitelController(MajitelRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public List<Majitel> getAll() {
        return repository.findAll();
    }
}
