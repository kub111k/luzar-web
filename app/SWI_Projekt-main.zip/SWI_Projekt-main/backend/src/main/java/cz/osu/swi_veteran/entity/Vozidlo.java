package cz.osu.swi_veteran.entity;

import jakarta.persistence.*;


@Entity
@Table(name = "vozidlo")
public class Vozidlo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_vozidlo") // Tímto natvrdo řeknete, který sloupec v DB to je
    private Long idVozidlo;

    @Column(name = "vin")
    private String vin;

    @Column(name = "znacka")
    private String znacka;

    @Column(name = "model")
    private String model;

    @Column(name = "rok_vyroby")
    private int rokVyroby;

    //vozidla-majitel
    @ManyToOne
    @JoinColumn(name = "id_majitel")
    private Majitel majitel;

    public Vozidlo() {

    }




    public Long getIdVozidlo() {
        return idVozidlo;
    }

    public void setIdVozidlo(Long idVozidlo) {
        this.idVozidlo = idVozidlo;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getZnacka() {
        return znacka;
    }

    public void setZnacka(String znacka) {
        this.znacka = znacka;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getRokVyroby() {
        return rokVyroby;
    }

    public void setRokVyroby(int rokVyroby) {
        this.rokVyroby = rokVyroby;
    }

    public Vozidlo(Long idVozidlo, String vin, String znacka, String model, int rokVyroby) {
        this.idVozidlo = idVozidlo;
        this.vin = vin;
        this.znacka = znacka;
        this.model = model;
        this.rokVyroby = rokVyroby;
    }

    public Majitel getMajitel() {
        return majitel;
    }

    public void setMajitel(Majitel majitel) {
        this.majitel = majitel;
    }
}

