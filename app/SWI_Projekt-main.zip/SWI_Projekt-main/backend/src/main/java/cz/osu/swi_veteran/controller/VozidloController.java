package cz.osu.swi_veteran.controller;

import cz.osu.swi_veteran.entity.Vozidlo;
import cz.osu.swi_veteran.repository.VozidloRepository;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import org.springframework.http.ResponseEntity;


@RestController
@RequestMapping("/api/vozidla")
@CrossOrigin(origins = "http://localhost:5173")
public class VozidloController {

    private final VozidloRepository vozidloRepository;

    public VozidloController(VozidloRepository vozidloRepository) {
        this.vozidloRepository = vozidloRepository;
    }

    @GetMapping
    public List<Vozidlo> getAllVozidla() {
        return vozidloRepository.findAll();
    }
}