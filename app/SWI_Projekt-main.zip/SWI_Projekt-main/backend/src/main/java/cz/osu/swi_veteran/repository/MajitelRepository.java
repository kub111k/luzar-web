package cz.osu.swi_veteran.repository;

import cz.osu.swi_veteran.entity.Majitel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MajitelRepository extends JpaRepository<Majitel, Long> {
}
