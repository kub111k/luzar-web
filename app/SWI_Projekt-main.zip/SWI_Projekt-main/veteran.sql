-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Počítač: 127.0.0.1
-- Vytvořeno: Pon 16. úno 2026, 11:04
-- Verze serveru: 10.4.32-MariaDB
-- Verze PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáze: `veteran`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `akce`
--

CREATE TABLE `akce` (
  `id_akce` bigint(20) UNSIGNED NOT NULL,
  `nazev` varchar(200) NOT NULL,
  `datum` date NOT NULL,
  `misto` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `dil`
--

CREATE TABLE `dil` (
  `id_dil` bigint(20) UNSIGNED NOT NULL,
  `nazev` varchar(100) NOT NULL,
  `vyrobce` varchar(100) DEFAULT NULL,
  `cena_jednotkova` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `majitel`
--

CREATE TABLE `majitel` (
  `id_majitel` int(11) NOT NULL,
  `jmeno` varchar(50) NOT NULL,
  `prijmeni` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telefon` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `servisni_zaznam`
--

CREATE TABLE `servisni_zaznam` (
  `id_zaznam` bigint(20) UNSIGNED NOT NULL,
  `id_vozidlo` int(11) DEFAULT NULL,
  `datum` date NOT NULL DEFAULT curdate(),
  `popis` text NOT NULL,
  `cena_prace` decimal(12,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `spotreba_dilu`
--

CREATE TABLE `spotreba_dilu` (
  `id_zaznam` int(11) NOT NULL,
  `id_dil` int(11) NOT NULL,
  `mnozstvi` int(11) NOT NULL CHECK (`mnozstvi` > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `ucast_na_akci`
--

CREATE TABLE `ucast_na_akci` (
  `id_vozidlo` int(11) NOT NULL,
  `id_akce` int(11) NOT NULL,
  `umisteni_v_soutezi` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `vozidlo`
--

CREATE TABLE `vozidlo` (
  `id_vozidlo` int(11) NOT NULL,
  `vin` char(17) NOT NULL,
  `znacka` varchar(50) NOT NULL,
  `model` varchar(50) NOT NULL,
  `rok_vyroby` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexy pro exportované tabulky
--

--
-- Indexy pro tabulku `akce`
--
ALTER TABLE `akce`
  ADD PRIMARY KEY (`id_akce`);

--
-- Indexy pro tabulku `dil`
--
ALTER TABLE `dil`
  ADD PRIMARY KEY (`id_dil`);

--
-- Indexy pro tabulku `majitel`
--
ALTER TABLE `majitel`
  ADD PRIMARY KEY (`id_majitel`);

--
-- Indexy pro tabulku `servisni_zaznam`
--
ALTER TABLE `servisni_zaznam`
  ADD PRIMARY KEY (`id_zaznam`);

--
-- Indexy pro tabulku `spotreba_dilu`
--
ALTER TABLE `spotreba_dilu`
  ADD PRIMARY KEY (`id_zaznam`,`id_dil`);

--
-- Indexy pro tabulku `ucast_na_akci`
--
ALTER TABLE `ucast_na_akci`
  ADD PRIMARY KEY (`id_vozidlo`,`id_akce`);

--
-- Indexy pro tabulku `vozidlo`
--
ALTER TABLE `vozidlo`
  ADD PRIMARY KEY (`id_vozidlo`);

--
-- AUTO_INCREMENT pro tabulky
--

--
-- AUTO_INCREMENT pro tabulku `akce`
--
ALTER TABLE `akce`
  MODIFY `id_akce` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `dil`
--
ALTER TABLE `dil`
  MODIFY `id_dil` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `servisni_zaznam`
--
ALTER TABLE `servisni_zaznam`
  MODIFY `id_zaznam` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
